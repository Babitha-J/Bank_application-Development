#import random

singels = {'0': "ZERO", '1': "ONE", '2': "TWO", '3': "THREE", '4': "FOUR", '5': "FIVE", '6': "SIX", '7': "SEVEN",
           '8': "EIGHT", '9': "NINE", }
sin = {'11': "ELEVEN", '12': "TWELVE", '13': "THIRTEEN", '14': "FOURTEEN",
       '15': "FIFTEEN", '16': "SIXTEEN", '17': "SEVENTEEN", '18': "EIGHTEEN", '19': "NINETEEN"}
tens = {'0': "", '1': "TEN", '2': "TWENTY", '3': "THIRTY", '4': "FORTY", '5': "FIFTY", '6': "SIXTY", '7': "SEVENTY",
        '8': "EIGHTY",
        '9': "NINTY"}
hundreds = {'1': "ONE", '2': "TWO", '3': "THREE", '4': "FOUR", '5': "FIVE", '6': "SIX", '7': "SEVEN",
            '8': "EIGHT", '9': "NINE"}
thousands = {'1': "ONE", '2': "TWO", '3': "THREE", '4': "FOUR", '5': "FIVE", '6': "SIX", '7': "SEVEN",
             '8': "EIGHT", '9': "NINE"}
# choice = str(random.randrange(0, 9999))
choice = input()
print(choice)
try:
    if choice in singels:
        print(singels[choice])

    elif choice in sin:
        print(sin[choice])

    elif len(choice) == 2:
        if choice[1] == '0':
            print(tens[choice[0]])
        else:
            print(f"{tens[choice[0]]} {(singels[choice[1]])}")

    elif len(choice) == 3:
        if choice[2] == '0':
            print(f"{hundreds[choice[0]]} HUNDRED {tens[choice[1]]}")
        elif choice[1: 3] in sin:
            print(f"{hundreds[choice[0]]} HUNDRED {sin[choice[1: 3]]}")
        elif choice[1] == '0':
            print(f"{hundreds[choice[0]]} HUNDRED {singels[choice[2]]}")

        else:
            print(f"{hundreds[choice[0]]} HUNDRED {tens[choice[1]]} {(singels[choice[2]])}")

    elif len(choice) == 4:
        if choice[1] == '0' and choice[3] == '0':
            print(f"{thousands[choice[0]]} THOUSAND {tens[choice[2]]}")
        elif choice[1] == "0":
            if choice[2: 4] in sin:
                print(f"{thousands[choice[0]]} THOUSAND {sin[choice[2: 4]]}")
            else:
                print(f"{thousands[choice[0]]} THOUSAND {tens[choice[2]]} {singels[choice[3]]}")
        elif choice[2] == "0":
            print(f"{thousands[choice[0]]} THOUSAND {hundreds[choice[1]]} HUNDRED {singels[choice[3]]}")
        elif choice[3] == "0":
            print(f"{thousands[choice[0]]} THOUSAND {hundreds[choice[1]]} HUNDRED {tens[choice[2]]} ")
        elif choice[2: 4] in sin:
            print(f"{thousands[choice[0]]} THOUSAND {hundreds[choice[1]]} HUNDRED {sin[choice[2:4]]}")

        else:
            print(
                f"{thousands[choice[0]]} THOUSAND {hundreds[choice[1]]} HUNDRED {tens[choice[2]]} {singels[choice[3]]}")
    else:
        print("Out of range")
except KeyError:
    print("first 0 is not valid")